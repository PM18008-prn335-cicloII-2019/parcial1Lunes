/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.ues.occ.ingenieria.prn335_2019.cine.boundary.servlet;

/**
 *
 * @author jcpenya
 */

public class MenuConsumibleServletTest {

    public MenuConsumibleServletTest() {
    }
    
    public String getCarnet(){
       return null; 
    }

   
}
